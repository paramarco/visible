$( document ).on( "mobileinit", function() {
	$.mobile.defaultPageTransition = 'none';
	$.mobile.linkBindingEnabled = false;
	$.mobile.allowCrossDomainPages = true; 
});